/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package window;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Piya
 */
public class Main {

   static int consider(String s)
    {
        int length=s.length();
        if(length==1)
            return 1;
        else
        {
            String sub=s.substring(0, 2);
            if((s.length()==2)&&sub.compareTo("27")<0)
                return 2;
            else if(sub.compareTo("27")<0)
                return (consider(s.substring(2))+consider(s.substring(1)));
            else
                return consider(s.substring(1));

        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        String s;
        
             
        BufferedReader br= new BufferedReader(new FileReader("input.txt"))   ;
        while(true)
        {
            s=br.readLine();
            if(s.equalsIgnoreCase("0"))
                break;
            else
                System.out.println(consider(s));

        }
    }

}
