import java.lang.*;
import java.util.*;

class hello{
	
	public static void main(String args[]){
	
		while (true){}
	}
}
