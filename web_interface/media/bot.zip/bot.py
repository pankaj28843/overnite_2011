#!/usr/local/bin/python

import mechanize, os, re, sys
ROOT_PATH = os.path.dirname(__file__)
FILENAME = 'test_codes/sort.c'
LANGUAGE = 'c'
br = mechanize.Browser()

def address(SERVER, URL):
    address = "http://%s/"%(SERVER)
    return address+URL

def bot(SERVER):        
    br.open(address(SERVER, '/contest/problem/1/'))
    br.select_form(nr=1)    
    br['language']=[LANGUAGE]
    br.form.add_file(open(FILENAME), 'text/plain', FILENAME)    
    br.form.set_all_readonly(False)
    br.submit()

if __name__=='__main__':
    try:
        pass
        SERVER = sys.argv[1]
        for i in range(100):
            bot(SERVER)
    except IndexError:
        print "Please provide the server address.\n"


