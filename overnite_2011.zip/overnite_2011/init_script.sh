cd web_interface
mkdir files
mkdir files/inputs web_interface/files/outputs files/programs files/temp 
cp -r files/inputs files/outputs files/programs files/temp/
chown -R www-data files/
