#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	char array[]={'M','D','C','L','X','V','I'};
	int cd[]={1000,500,100,50,10,5,1};
	char x[100],y[100];
	printf("Enter the first number :\n");
	scanf("%s",x);
	printf("Enter the second number :\n");
	scanf("%s",y);
	int l1,l2,i,j;
	l1=strlen(x);
	l2=strlen(y);
	int count[10]={0};
	int m=0;
	for(i=0;i<7 && m<l1;i++)
	{
		int c=0;
		while(x[m]==array[i])
		{
			c++;
			m++;
		}
		count[i]=c;
	}
	m=0;
	for(j=0;j<l2;j++)
	{
		for(i=0;i<7;i++)
		{
		if(count[i]!=0)
		{count[i]+=cd[i]-1;}
		
		}
	}
	
	
	for(i=0;i<7;i++)
	{
		printf("count %d\n",count[i]);}
/*	for(i=0;i<7;i++)
		{
			for(j=0;j<count[i];j++)
			{
				printf("%c",array[i]);
			}
		}*/
	printf("\n");
	return 0;
}

