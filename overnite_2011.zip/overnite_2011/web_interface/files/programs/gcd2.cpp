#include<iostream>
#include<string>
using namespace std;
long call_div(string number,long div)
{
     	string::size_type now;
     	long extra=0;
     	for(now=0;now<number.size();++now)
	{
            	extra=(extra*10) + (number[now]-'0');
        	extra=extra%div;
  	}
  	return extra;
}
long gcd(long a,long d)
{
	if(d==0)
	        return a;
    else
        return gcd(d,a%d);
}
int main()
{
     	string b;
     	long a,g;
	int t;
	cin>>t;
     	while(t--)
	{
		cin>>a>>b;
		if(a!=0)
		{	
			long d=call_div(b,a);
			g=gcd(a,d);            	
            		cout<<g<<endl;
		}
        else if(b[0]==0)
             cout<<0<<endl;
        else
             cout<<b<<endl;
     	}
     	return 0;
}


