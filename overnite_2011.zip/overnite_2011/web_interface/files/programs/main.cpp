#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
using namespace std;
int gcd(long a,long b)
{
    if (b==0)return a;
    else
    return gcd(b,a%b);
}

int main()
{
  // freopen("input.in","r",stdin);
   // freopen("output.in","w",stdout);
    long test;
    cin>>test;
    char s[251],temp[251];
    while(test--)
    {
        long a,b;
        cin>>a>>s;
        while(strlen(s)>9)
        {
            strncpy(temp,s,9);
            temp[9]='\0';
            b=atol(temp);
            b=b%a;
            sprintf(s,"%ld%s",b,s+9);
        }
        b=atol(s);

    cout<<gcd(a,b)<<endl;

    }
    return 0;
}
