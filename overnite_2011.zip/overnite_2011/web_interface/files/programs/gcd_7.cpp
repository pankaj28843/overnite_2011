#include<stdio.h>
#include<iostream>
using namespace std;
int main()
{
int A,n,t,i;
char B[253];
scanf("%d",&t);
while(t--)
{
	n=0;
	scanf("%d%s",&A,B);
	if(A)
	{
	for(i=0;B[i];i++)
	{
		n*=10;
		n+=B[i]-'0';
		if(n>=A)
		n%=A;
	}
	while(n)
	{
		i=A;
		A=n;
		n=i%n;
	}
	printf("%d\n",A);
	}
        else
        printf("%s\n",B);
}
return 0;
}
