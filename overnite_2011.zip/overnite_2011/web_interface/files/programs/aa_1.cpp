#include<iostream>
#include<stdio.h>
using namespace std;
bool sol(int k,int l)
{
        if(l==0)
                return true;
        int x=2,p=0;
        while(l>x)
        {
                l-=x;
                x*=2;
                p++;
        }
        if(p>=k)
                return 0;
        sol(p,l-1);
}
int main()
{
        int k,l,m,t;
        scanf("%d",&t);
        while(t--)
        {
                scanf("%d%d%d",&k,&l,&m);
                while(m--)
                {
                        if(sol(k,l))
                                printf("(");
                        else
                                printf(")");
                        l++;
                }
                printf("\n");
        }
}
