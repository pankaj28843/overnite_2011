#include <vector> 
#include <list> 
#include <map> 
#include <set> 
#include <deque> 
#include <queue> 
#include <stack> 
#include <bitset> 
#include <algorithm> 
#include <functional> 
#include <numeric> 
#include <utility> 
#include <sstream> 
#include <iostream> 
#include <iomanip> 
#include <cstdio> 
#include <cmath> 
#include <cstdlib> 
#include <cctype> 
#include <string> 
#include <cstring> 
#include <cstdio> 
#include <cmath> 
#include <ctime> 
 
using namespace std; 

static long long int ds[5001];

long long int dps (string s) {
  if(s.size() == 1) return 1;
  ds[0] = 1;
  int n = s.size();
  if(s[0] <= '2' && s[1] <= '6')
    ds[1] = 2;
  else if(s[0] == '1')
    ds[1] = 2;
  else
    ds[1] = 1;
  if(s[1] == '0')
    ds[1] = 1;
  for(int i = 2; i < n; ++i) {
    if(s[i] == '0')
      ds[i] = ds[i - 2];
    else if(s[i - 1] != '0' && s[i - 1] <= '2' && s[i] <= '6')
      ds[i] = ds[i - 1] + ds[i - 2];
    else if(s[i - 1] == '1')
      ds[i] = ds[i - 1] + ds[i - 2];
    else if(s[i] != '0')
      ds[i] = ds[i - 1];
  }
  return ds[n - 1];
}
 
int main () { 
 for (;;) {
   string s;
   cin >> s;
   if (s == "0") break;
   cout << dps (s) << endl;
 } 
 return 0; 
}
