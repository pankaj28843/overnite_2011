#include <iostream>
#include <string>
#include <vector>

using namespace std;

unsigned long calculate (int);
unsigned long ctr=0;
string str;
unsigned long memory[5000];
int main()
{
  while(1)
    {
      for(int i=0; i<5000; i++) memory[i]=0;
      cin>>str;
      if(str.at(0) =='0') break;
      cout<<calculate(0)<<endl;
  }
  return 0;
}

unsigned long calculate(int loc)
{
  if(memory[loc] != 0) return memory[loc];
  if(str.length()-loc<=1) return 1;
  bool two = str[loc]<='2' && str[loc+1]<='6';
  if(two) 
    {
      memory[loc] = calculate(loc+1)+ calculate(loc+2);
      return memory[loc];
    }
  else 
    {
      memory[loc] = calculate((loc+1));
      return memory[loc];
    }
}
