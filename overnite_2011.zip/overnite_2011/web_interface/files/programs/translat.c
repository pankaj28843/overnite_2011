#include<stdio.h>
#include<string.h>

int possibleDecoding ( char *num , int len )
{
  int i , s = 1 , d = 0 , num1 , num2 , temp ;
  for ( i = len-1 ; i > 0 ; i -- )
  {
	 num1 = num[i] - '0' ;
	 num2 = num1 + 10 * (num[i-1]-'0') ;
	 printf ( "\nnum2 is : %d, %d", num1, num2 ) ;
	 temp = s + d ;
	 if ( num2 <= 26 )
		d = s ;
	 else
		d = 0 ;
	s = temp ;
  }
  return s+d ;
}

int main()
{
  char num[50] ;
  int len ;
  do
  {
	 printf ( "\nEnter the number \t" ) ;
	 scanf ( "%[^\n]s" , num ) ;
	 fflush ( stdin ) ;
	 len = strlen ( num ) ;
	 if ( len == 1 && num[0] == '0' )
		break ;
	 printf ( "\nPossible decoding : %d" , possibleDecoding ( num, len ) ) ;
  }
  while ( 1 ) ;
  return 0 ;
}