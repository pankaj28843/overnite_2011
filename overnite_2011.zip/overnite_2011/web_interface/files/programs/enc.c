#include <stdio.h>
#include <string.h>
#define MX 5010
typedef long long LL;

char s[MX];
LL mm[MX];

LL get(int p)
{
	if(s[p]==0) return 1;
	if(mm[p]==-1)
	{
		mm[p] = get(p+1);
		if(s[p+1]!=0)
		{
			if(s[p]=='1') mm[p] += get(p+2);
			if(s[p]=='2' && s[p+1]<='6') mm[p] += get(p+2);
		}
	}
	return mm[p];
}

int main()
{
	while(1)
	{
		scanf("%s",s);
		if(s[0]=='0') break;
		memset(mm,-1,sizeof mm);
		printf("%lld\n",get(0));
	}
	
	return 0;
}
