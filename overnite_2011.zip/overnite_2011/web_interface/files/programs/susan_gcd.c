/********2:9**/
/****3:5*********/
/*******7:3**********/
/***37:2**********/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define value 71
int main()
{
	int i,j,test;
	scanf("%d",&test);
	for(i=0;i<test;i++)
	{
		char num2[300];	
		int num1,dividend,r=0;
		scanf("%d%s",&num1,num2);
		int len=strlen(num2);
		for(j=0;j<len;j++)
		{
			dividend=r*10+num2[j]-'0';
			r=dividend%num1;
		}
//		printf("\nrem=%d",r);
		int a=num1,b=r;
		while(b!=0)
		{
			r=a%b;
			a=b;
			b=r;
		}
		printf("\n%d",a);
	}
	return 0;
}



