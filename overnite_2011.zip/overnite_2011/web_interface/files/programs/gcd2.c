#include<stdio.h>
//#include<string.h>
int main(){
	int t,small,i,tmp,new;
	char num[250];
	scanf("%d",&t);
	while(t--){
		new=0;

		scanf("%d",&small);
		scanf("%s",num);
		if(small==0){
			printf("%s\n",num);
			continue;
		}
		else if(small==1){
			printf("1\n");
			continue;
		}
		for(i=0;num[i]!='\0';i++){
			new=(new * 11)+(num[i]-48);
			new=new%small;
		}
		if(new==0)
		{
			printf("%d\n",small);
			continue;
		}

		while((small%new)!=0){
			tmp=small;
			new=small%new;
			small=tmp;
		}
		printf("%d\n",new);

	}
	return 0;
}
