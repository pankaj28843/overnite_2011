#include <iostream>
#include <string>
#include <vector>

using namespace std;

unsigned long calculate (int);
unsigned long ctr=0;
string str;
vector<unsigned long> memory;
int main()
{
  while(1)
    {
      cin>>str;
      if(str.at(0) =='0') break;
      memory.clear();
      memory.reserve(str.length());
      memory.assign(5000, -1);
      cout<<calculate(0)<<endl;
    }
  return 0;
}

unsigned long calculate(int loc)
{
  if(memory[loc] != -1) return memory[loc];
  if(str.length()-loc<=1) return 1;
  bool two = str[loc]<='2' && str[loc+1]<='6';
  if(two) 
    {
      memory[loc] = calculate(loc+1)+ calculate(loc+2);
      return memory[loc];
    }
  else 
    {
      memory[loc] = calculate((loc+1));
      return memory[loc];
    }
}
