#include<cstdio>
#include<cstring>
//#include<stdlib.h>

int gcd(int x,int y)
{
while(x%y)
{
int r;
r=x%y;
x=y;
y=r;
}
return y;
}

int main()
{
int t;
scanf("%d",&t);
while(t--)
{
int a;
char b[300];
scanf("%d%s",&a,b);
if(a==0) {printf("0\n");continue;}

int r,n;
r=0;
n=strlen(b);
if(b[0]=='0'&& n==1) {printf("0\n");continue;}
int i;
for(i=0;i<n;i++)
{
r=(10*r+b[i]-'0')%a;
}
if(r==0) printf("%d\n",a);
else printf("%d\n",gcd(a,r));


}


return 0;
}
