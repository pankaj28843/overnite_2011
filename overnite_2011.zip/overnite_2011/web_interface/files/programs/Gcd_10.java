import java.io.*;
import java.util.regex.*;
class Gcd
{
 static int[] ip;
 public static void main(String a[]){ 
try{ 
   File file=new File("input.txt");
   FileWriter fw=new FileWriter(file);
   PrintWriter pw=new PrintWriter(fw);
   BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
System.out.println("enter the no of input to be taken");
   int no=Integer.parseInt(br.readLine());
   pw.println(no);
      for(int i=0;i<no;i++){
        pw.print(Integer.valueOf(br.readLine())+" ");
        pw.println(Integer.valueOf(br.readLine()));
        }
pw.flush();
pw.close();

FileReader fr=new FileReader(file);
BufferedReader bri=new BufferedReader(fr);
Pattern p=Pattern.compile("\\d([^\\s])*");


String st;
for(int i=0;i<=no;i++){
 
st=bri.readLine();
if(i==0)continue;
Matcher m=p.matcher(st);  
     
// System.out.println("nos "+st+" ");


    while(m.find()){
          int[] ip=new int[2];
          int in=0;
          ip[in]=Integer.parseInt(m.group()); 
          in++;
   int op=gcd(ip[0],ip[1]);
System.out.println(op);
         // System.out.println(m.group());
          }

 
}   
  fr.close();  
    }
catch(IOException e){
System.out.println("File not found");
     }
 


  }
static int gcd(int a, int b)
{
  if (b==0)
    return a;
  else
    return gcd(b,a%b);
}
}
