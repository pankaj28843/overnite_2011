import java.math.BigInteger;
import java.util.Scanner;
class hcf
{
    public static void main(String args[])
    {
        Scanner sc =new Scanner(System.in);
        int i,input=sc.nextInt();
        BigInteger ans,a,b;
        for(i=1;i<=input;i++)
        {
            a=new BigInteger(sc.next());
            b=new BigInteger(sc.next());
            ans=gcd(a,b);
            System.out.println(ans);
        }
    }
    public static BigInteger gcd(BigInteger a, BigInteger b)
    {
        if (b.compareTo(new BigInteger("0"))==0)
            return a;
        else
            return gcd(b,a.remainder(b));
    }
}