#include <iostream>
#include <string>
using namespace std;
int gcd(int a,int b) 
{
	if(b==0)
		return a;	
 
	return gcd(b,a%b); 
}
 
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int a=0,b=0;
		cin>>a;
 
		string B;
		cin>>B;
		
		if(a == 0)
		{
			cout<<B<<endl;
			continue;
		}
 
		for(int i=0 ; i<B.size() ; i++)
			b = (b*10 + B[i]-'0') % a;
	
		cout<<gcd(a,b)<<endl;
	}
 
	return 0;
}