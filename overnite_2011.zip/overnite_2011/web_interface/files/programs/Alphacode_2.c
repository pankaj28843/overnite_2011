#include<stdio.h>
#include<string.h>
int main(){       
        char ar[6000];
        while(scanf("%s",ar),strcmp(ar,"0")!=0)
        {            
            int l=strlen(ar);            
            int dp[l];int i;
            for(i=0;i<l;i++)
            dp[i]=0;
            if(ar[l-1]!='0')
            dp[l-1]=1;            int j;
            for(j=l-2;j>=0;j--)
            {
                int a=ar[j]-'0',b=ar[j+1]-'0';
                if(j==(l-2)  && (10*a+b)<=26)
                {
                if(a!=0)   
                dp[j]=1+dp[j+1];                
                }                
                else if(j==(l-2) && (10*a+b)>26)
                dp[j]=dp[j+1];
                else if(j!=(l-2) && (10*a+b)<=26)
                {
                    if(a!=0)
                    dp[j]=dp[j+1]+dp[j+2];
                }
                else
                {                    
                    dp[j]=dp[j+1];
                }                
            }
            printf("%d\n",dp[0]);
        }
        return(0);    
}
