#include<stdio.h>
#include<string.h>
		
	int goR(char c[],int p,int v);
	int goP(char c[],int p,int v);	
	int goL(char c[],int p,int v){
		v=2*v;
		switch (c[p]){
			case 'L':
				return goL(c,p+1,v);
				break;
			case 'R':
				return goR(c,p+1,v);
				break;
			case 'P':
				return goP(c,p+1,v);
				break;
			case '*':
				return goL(c,p+1,v)+goR(c,p+1,v)+goP(c,p+1,v);
				break;
			case '\0':
				return v;
				break;		
		}
	}
	int goR(char c[],int p,int v){
		v=2*v+1;
		switch (c[p]){
			case 'L':
				return goL(c,p+1,v);
				break;
			case 'R':
				return goR(c,p+1,v);
				break;
			case 'P':
				return goP(c,p+1,v);
				break;
			case '*':
				return goL(c,p+1,v)+goR(c,p+1,v)+goP(c,p+1,v);
				break;
			case '\0':
				return v;
				break;			
		}
	}
	int goP(char c[],int p,int v){
		switch (c[p]){
			case 'L':
				return goL(c,p+1,v);
				break;
			case 'R':
				return goR(c,p+1,v);
				break;
			case 'P':
				return goP(c,p+1,v);
				break;
			case '*':
				return goL(c,p+1,v)+goR(c,p+1,v)+goP(c,p+1,v);
				break;
			case '\0':
				return v;
				break;			
		}
	}
			

int main(){
	char path[10000];
	scanf("%s",path);
	int pos=0;
	int val=1;
	switch(path[pos]){
			case 'L':
				val= goL(path,pos+1,val);
				break;
			case 'R':
				val= goR(path,pos+1,val);
				break;
			case 'P':
				val= goP(path,pos+1,val);
				break;
			case '*':
				val= goL(path,pos+1,val)+goR(path,pos+1,val)+goP(path,pos+1,val);
				break;
			case '\0':
				break;
	}
	printf("%d\n",val);
	return 0;
}		
	



	
