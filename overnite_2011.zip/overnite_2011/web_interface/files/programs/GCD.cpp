#include<fstream.h>
#include<conio.h>

int gcd(int a, int b)
{
  if (b==0)
    return a;
  else
    return gcd(b,a%b);
}

void main()
{
     int a,b;
     cin>>a;
     cin>>b;
     int d;
     d=gcd(a.b);
     cout<<d;
     getch();
}
