import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.lang.String;
import java.lang.Integer;
class gcd{
    int return_gcd(int a,int b ){
	if(b==0)
	    return a;
	else
	    return return_gcd(b,a%b);
    }
}

class prog1{
    public static void main(String args[]) throws java.io.IOException{
	BufferedReader data=new BufferedReader(new InputStreamReader(System.in));
	int A,length_A;
	String B;
	int length_B;
	String A_str;
	int first_A;
	int first_B;
	int Fb;
	gcd obj=new gcd();
	int B_num;
	int GCD,j=0;
	int userChoice;
	int k,count=0,i;
	
	System.out.println("Input:");
	userChoice=Integer.parseInt(data.readLine());


	int[] choice=new int[userChoice];

	
	for(k=0;k<userChoice;k++)
	    {
		StringTokenizer st=new StringTokenizer(data.readLine());
		

		A_str=st.nextToken();
		A=Integer.parseInt(A_str);

		B=st.nextToken();
		length_A=A_str.length();
		length_B=B.length();

		
		first_A=Integer.parseInt(A_str.substring(0,1));
		first_B=Integer.parseInt(B.substring(0,1));
		String B_Arr;
	
		while(B.length()>length_A+1)
		    {
			if(first_B>first_A){
			    B_Arr=B.substring(0,length_A);
	    
			    Fb=Integer.parseInt(B_Arr);

			    Fb=Fb-A;

			    B= Integer.toString(Fb) + B.substring(length_A);
	    
			}
			else
			    {
				B_Arr=B.substring(0,length_A+1);
		
				Fb=Integer.parseInt(B_Arr);
		
				Fb=Fb-A;
			
				B= Integer.toString(Fb) + B.substring(length_A+1);
			    }
			first_B=Integer.parseInt(B.substring(0,1));
		
		    }

		B_num=Integer.parseInt(B);
		GCD=obj.return_gcd(A,B_num);
		choice[count++]=GCD;
		//System.out.println(GCD);
    
		
	    }
	System.out.println("\nOutput:");
	for(i=0;i<userChoice;i++)
	    System.out.println(choice[i]);
    }
}


