/**
 * @(#)Gcd.java
 *
 *
 * @author 
 * @version 1.00 2011/1/15
 */
import java.util.*;
import java.math.*;
public class Gcd {

    public Gcd() {
    }
    public static void main (String[] args) {
    	Scanner s=new Scanner(System.in);
    	int n=s.nextInt();
    	int ans[]=new int[n];
    	for(int i=0;i<n;i++)
    	{
    		BigInteger a,b;
    		a=s.nextBigInteger();
    		b=s.nextBigInteger();
    		BigInteger c =a.gcd(b);
    		//ans[i]=c.intValue();
    		System.out.println (c.intValue());
    	}
    	/*for(int i=0;i<ans.length;i++)
    	{
    		System.out.print(ans[i]);
    		if(i!=ans.length-1)System.out.println ();
    	}*/
}
static int gcd(BigInteger a, BigInteger b)
{
  if (b.intValue()==0)
    return a.intValue();
  else
    return gcd(b,a.mod(b));
}
    
}