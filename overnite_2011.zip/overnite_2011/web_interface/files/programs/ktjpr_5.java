import java.io.*;
import java.util.*;
//import javax.swing.*;

import java.math.BigInteger;
public class ktjpr {
        
    /**
     * Creates a new instance of <code>ktjpr</code>.
     */
    public ktjpr() {
    }
    
    /**
     * @param args the command line arguments
     */
 public static  BigInteger gcd(BigInteger a, BigInteger b)
{
BigInteger a1=new BigInteger("0"); 	
  if(b.compareTo(a1)==0)
    return a;
  else
  {
  	//if(a.compareTo(b)>0)
  		//return gcd(a,b.mod(a));
  		//System.out.println("\n\na-" + a + "b- " + b);
  	return gcd(b,a.mod(b));
  }
    
}
     
    public static void main(String[] args) throws IOException{
       
       
       FileInputStream fis;
       BufferedReader br;
       String line;
       int i=0,y=0;
       int count=0,linec=0;
       BigInteger c1=new BigInteger("10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
       BigInteger c2=new BigInteger("40000"); 
       	try{
    	
			fis = new FileInputStream( "input.txt" );
			br = new BufferedReader ( new InputStreamReader ( fis ) ) ;
			while((line = br.readLine())!=null)
		 	{
		 		if(i==0)
		 		{
		 			count=Integer.parseInt(line);
		 			//System.out.println("\n\nNo of test cases = " + count);
		 			i=1;
		 			continue;
		 		}
		 		linec++;
		 		if(linec>count)
		 			{//System.out.println(" INPUT EXCEEDED LIMIT...EXITING");
		 			System.exit(0);
		 			}
		 		
		 		String s[]=new String[2];
		 		s=line.split(" ");
		 		BigInteger b=new BigInteger(s[0]);
		 		BigInteger c=new BigInteger(s[1]);
		 		if(c.compareTo(BigInteger.ZERO)==0)
		 		{
		 		//	System.out.println("ERROR!!CANNOT DIVIDE BY ZERO ");
		 			System.exit(0);
		 		}
		 		if(b.compareTo(c1)>0 || c.compareTo(c2)>0 || c.compareTo(b)>0 || c.compareTo(BigInteger.ZERO)<0 )
		 		{
		 			//System.out.println("ERROR in input size\n");
		 			System.exit(0);	
		 		}
		 			
		 		//System.out.println(b);
		 		System.out.println(gcd(b,c));
		 		
		 		
		 		//do whatever with this line..!!
		 	}
       
       	}
       	catch( IOException ioe )
		  {			System.out.println(ioe);						
		  }	
		  
		 	
       
       System.out.println();

    }
}