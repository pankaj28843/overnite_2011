#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int exp(int b,int n,int m)
{
 int x=1;
 int power=b%m;
 while(n!=0)
 {
	if(n%2)
	 x=(x*power)%m;
	power=(power*power)%m;
	n/=2;
 }
 return x;
}
int gcd(int a, int b)
{
  /*if (b==0)
    return a;
  else
    return gcd(b,a%b);*/
 int r;
 while(b!=0)
 {
  r=a%b;
  a=b;
  b=r;
 }
 return a;
}

int main()
{
 int num,a;
 char b[251];
 scanf("%d",&num);
 int i,len,d,rem,j;
 int res;
 for(i=0;i<num;i++)
 {
  strcpy(b,"");
  scanf("%d",&a);
  scanf("%s",b);
  len=strlen(b);
  rem=0;
  for(j=0;j<len;j++)
  {
   d=b[j]-'0';
   rem=rem+(d*exp(10,len-1-j,a))%a;
   rem=rem%a;
  }
  res=gcd(a,rem);
  printf("%d\n",res);
 }
 /*for(i=0;i<num;i++)
  printf("%ld\n",res[i]); 
 free(res);*/
 return 0;
}