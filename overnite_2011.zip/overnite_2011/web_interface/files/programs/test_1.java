import java.io.* ;

/*
 * input.txt
 *
 * 2
 * 4000 30000
 * 40000 100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
 *
 */

public class test
{
	FileInputStream fis ;
	BufferedReader br ;
	String totalInput ;

	public test ( )
	{
		fis = null ;
		br = null ;
		try
		{
			br = new BufferedReader ( new InputStreamReader ( ( fis = new FileInputStream ( "input.txt" ) ) )  ) ;
		}
		catch ( IOException ioe )
		{
			System.out.println ( "Err." ) ;
		}
	}
	
	public void getInput ( )
	{
		int total = 0;
		
		FileOutputStream fos = null ;
		BufferedWriter bw = null ;
		
		try
		{
			bw = new BufferedWriter ( new OutputStreamWriter ( fos = new FileOutputStream ( "output.txt" ) ) ) ;
		}
		catch ( IOException ioe )
		{
			System.out.println ( "Unable to write.." ) ;
		}
		
		try
		{
			totalInput = br.readLine() ;
			total = Integer.parseInt( totalInput ) ;
		}
		catch ( NumberFormatException nfe ) {
			System.exit( 0 ) ;
		}
		catch ( IOException ioe )
		{
			System.out.println ( "err.. Missing Input.." ) ;
			System.exit( 0 ) ;
		}
		
		for ( int i = 0 ; i < total ; i ++ )
		{
			String num1="" , num2="" ;
			try
			{
				String input = br.readLine() ;
				num1 = input.split( " " )[0] ;
				num2 = input.split( " " )[1] ;
				if ( num1.length() > num2.length() )
				{
					String temp = num1 ;
					num1 = num2 ;
					num2 = temp ;
				}
				else if ( num1.length() == num2.length() )
				{
					if ( num1.compareTo( num2 ) > 0 )
					{
						String temp = num1 ;
						num1 = num2 ;
						num2 = temp ;
					}
				}
				System.out.println ( result( num1 , num2 )) ;
			}
			catch ( IOException ioe ) {
				System.out.println ( "err" ) ;
			}
/*			try{
				String res = result( num1, num2 ) ;
				bw.write( res + "\n" ) ;}
			catch ( IOException ioe ) { 
			}*/
		}
		try {
		bw.close() ;
		fos.close() ;
		
		br.close() ;
		fis.close ( ) ;
		}catch ( IOException ioe ){
			System.out.println ( "Closing Error." ) ;
		}
	}

	private int gcd_test ( int a , int b)
	{
		if ( b == 0 )
			return a ;
		else return gcd_test( b, a%b ) ;
	}
	
	public String gcd ( String num1 , String num2 ) // 1<num1<40000 
	{
		String str = num2.substring( 0 , num1.length() ) ;
		int size = num1.length() ;
		int ii = Integer.parseInt( str ) ;
		int j = Integer.parseInt( num1 ) ;
		int temp = 0 ;
		
		for ( int i = size ; i <= num2.length() ; i++ ) 
		{
			temp = ii % j ;
			str = String.valueOf( temp ) ;
			if ( i >= num2.length() )
				break ;
			str += num2.substring( i , i+1 ) ;
			ii = Integer.parseInt( str ) ;
		}
		return  String.valueOf( temp ) ;
	}
	
	private String result ( String num1, String num2 )
	{
		String num = gcd ( num1 , num2 ) ;
		return String.valueOf(gcd_test( Integer.parseInt(num) , Integer.parseInt(num1) ) ) ;
	}
	
	public static void main (String[] args) 
	{
		test t = new test ( ) ;
		t.getInput() ;
	}
}

/*
 * output 
 *
 * 2000
 * 40000
 *
 */