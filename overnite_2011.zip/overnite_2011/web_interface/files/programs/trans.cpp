#include<string.h>
#include<iostream>
using namespace std;
int main(int argc,char* argv[])
{

for(int i=1;i<=sizeof(argv);i++)
{
	char *x=argv[i];
	for(int j=0;j<strlen(x);j++)
	{
		const char* xy1=x[j+1];
		char* xy2=x[j];
		if(strcat(xy2,xy1)<27)
			cout<<x[j]+x[j+1]<<"YAH"<<endl;
	}
}

/*for(char i=65;i<=64+26;i++)
	cout<<i<<"--"<<i-64<<endl;
*/
return 0;
}
/*
25114
1111111111
3333333333

6
89

BEAAD
BEKD
YAAD
YKD
BEAN
YAN



*/
