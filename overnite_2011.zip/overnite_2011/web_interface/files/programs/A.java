import java.math.*;
import java.util.*;

public class A{
	static BigInteger ZERO = BigInteger.ZERO;
	private static BigInteger GCD(BigInteger A, BigInteger B){
		if( B.equals(ZERO) )
			return A;
		return GCD(B, A.mod(B));
	}

	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		int T = in.nextInt();
		while(T-- > 0){
			BigInteger A = in.nextBigInteger();
			BigInteger B = in.nextBigInteger();
			System.out.println( GCD(B, A) );
		}
	}
}