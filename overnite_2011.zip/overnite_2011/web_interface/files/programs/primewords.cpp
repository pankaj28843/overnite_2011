#include<iostream>
#include<vector>
#define P 531169
using namespace std;
int A[P+10],B[P+10];
int a,b;
vector<int> PF;
vector<int> Power;

int mulmod(int a,int b,int c){
      long long x = 0,y=a%c;
      while(b > 0){
         if(b%2 == 1)  x = (x+y)%c;
         y = (y*2)%c;
         b >>= 1;
      }
      return x%c;
}

long long gcd(long long A, long long B) {
      long long x, y, u, v, m, n, a, b, q, r;
      x = 0; y = 1;
      u = 1; v = 0;
      for (a = A, b = B; 0 != a; b = a, a = r, x = u, y = v, u = m, v = n) {
      q = b / a;
      r = b % a;
      m = x - (u * q);
      n = y - (v * q);
      }
      return x;
}

long long GCD(long long a, long long b){
      long long temp;
      while(b>0){
         temp=b;
         b=a%b;
         a=temp;
      }
      return a;
}

void preprocess(){
      A[0]=1;
      for(int i=1;i<P+10;i++){
         long long temp=A[i-1];
         temp=(temp*i)%P;
         A[i]=(int)temp;
      }
}

long long bigpow(long long a,long long b,long long c){
      long long x=1,y=a; // long long is taken to avoid overflow of intermediate results
      while(b > 0){
         if(b%2 == 1)   x=(x*y)%c;
         y = (y*y)%c; // squaring the base
         b /= 2;
      }
      return x%c;
}

long long NCR(int N,int R){
      long long temp,f,t;
      long long result=(A[N]*(gcd(A[N-R],P)+P))%P;
      result=(result*(gcd(A[R],P)+P))%P;
      return result;
}

long long HCK(long long h,long long k){
      long long ans=1;
      if(h/P>0){
         int h1=h/P;
         h=h%P;
         int k1=k/P;
         k=k%P;
         if(h1<k1)
           return 0;
         ans=ans*NCR(h1,k1);
      }
      if(h<k)
         return 0;
      ans=(ans*NCR(h,k))%P;
      return ans;
}

long long FinalAns;
void Final(int div,bool isSF,int K,bool isEven){
      if(K==PF.size()||isSF==false)
      return ;
      int temp=PF[K]*div;
      isEven=isEven?false:true;;
      if(isSF){
         // cout<<temp<<endl;
         if(isEven)
           FinalAns+=HCK((a+b)/temp,b/temp);
         else
           FinalAns-=HCK((a+b)/temp,b/temp);
         FinalAns=(FinalAns+P)%P;
         for(int l=K+1;l<PF.size();l++)
            Final(temp,isSF,l,isEven);
       }
}

int main(){
      preprocess();
      int t,G,Q,l;
      scanf("%d",&t);
      while(t--) {
         scanf("%d %d",&a,&b);
         G=GCD(a,b);
         // cout<<G<<endl;
         Q=G;
         if(G==1){
           printf("%lld\n",HCK(a+b,b));
           continue;
         }
         for(int i=2;i*i<=G+10;i++){
           if(Q%i==0){
              PF.push_back(i);
              l=0;
              while(Q%i==0){
                  Q/=i;
                  l++;
              }
              Power.push_back(l);
           }
         }
         FinalAns=HCK(a+b,b);
         if(Q>1) {
             PF.push_back(Q);
             Power.push_back(1);
         }
         for(int i=0;i<PF.size();i++)      {
           // cout<<PF[i]<<" "<<Power[i]<<endl;
           int temp=PF[i];
          // cout<<temp<<endl;
           FinalAns-=HCK((a+b)/temp,b/temp);
           FinalAns=(FinalAns+P)%P;
           for(int l=i+1;l<PF.size();l++)
              Final(temp,1,l,0);
         }
         PF.clear();
         Power.clear();  
         printf("%lld\n",FinalAns);
      }
}
