#include <iostream>
#include <string>

using namespace std;

int calculate (string);
int ctr=0;

int main()
{
  string input;

  cin>>input;

  cout<<calculate(input);
  cout<<"my answer "<<ctr;
  return 0;
}

int calculate(string str)
{
  if(str.length()<=1) return 1;
  bool two = str[0]<='2' && str[1]<='6';
  if(two) return calculate(str.substr(1))+ calculate(str.substr(2));
  else return calculate(str.substr(1));	             
}

  
  
