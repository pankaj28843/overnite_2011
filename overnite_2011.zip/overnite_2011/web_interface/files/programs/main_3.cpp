#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
   //freopen("input.in","r",stdin);
   // freopen("output.in","w",stdout);

    long c[217][109],l[217][109];
    c[0][0]=0;
    for(int i=1;i<109;i++)
    {
        c[0][i]=1;
        l[0][i]=0;
    }
    for(int i=1;i<217;i++)
    {
        c[i][0]=1;
        l[i][0]=0;
    }
    for(int i=1;i<217;i++)
    {
        for(int j=1;j<109&&j<=i;j++)
        {
            c[i][j]=(c[i-1][j]+c[i-1][j-1])%531169;
        }
    }
    for(int i=1;i<217;i++)
    {
        for(int j=1;j<109&&j<=i;j++)
        {
            l[i][j]=c[i][j];
            for(int k=2;k<i;k++)
            {
                if((i)%k==0)
                {
                    l[i][j]-=l[i/k][j/k];
                }
            }
        }
    }
    int test;
    cin>>test;
    int ans=0;
    while(test--)
    {
        ans=0;
        int x,y;
        cin>>x>>y;
        cout<<l[x+y][y]<<endl;
    }

    return 0;
}
