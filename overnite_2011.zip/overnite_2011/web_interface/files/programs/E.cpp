#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <string>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
using namespace std;

typedef unsigned int uint;
typedef long long int64;
typedef unsigned long long uint64;

#define FOI(i, A, B) for(i=A; i<=B; i++)
#define FOD(i, A, B) for(i=A; i>=B; i--)

#define INF    INT_MAX
#define EPS    1e-10
#define sqr(x) (x)*(x)

bool BIG(string A, string B){
     int i;
     int lA = A.length(), lB = B.length(), L = min(lA, lB);
     if( lA != lB ){
         if( lA > lB )
             return true;
         else
             return false;
     }
     FOI(i, 0, L-1){
            if( A[i] != B[i] )
                return ( A[i] > B[i] );
     }
     return false;
}

int main(){
    int T, t;
    scanf("%d\n", &T);
    FOI(t, 1, T){
           string str;
           vector<string> vec;
           getline(cin, str);
           int L = str.length(), i, j;
           string temp = "";
           FOI(i, 0, L-1){
                  if( isdigit(str[i]) )
                      temp += str[i];
                  else if( temp.length() > 0 ){
                       vec.push_back(temp);
                       temp = "";
                  }
           }
           if( isdigit(str[L-1]) )
               vec.push_back(temp);
           FOI(i, 0, vec.size()-1)
                  cout << vec[i] << endl;
           string S = vec[vec.size() - 1], zero = "", ans = "";
           int lS = S.length();
           char arr[lS];
           FOI(i, 0, lS-1)
                  arr[i] = S[i];
           bool stat = true;
           while( stat ){
                  sort(arr, arr+lS);
                  do{
                       FOI(i, 0, lS-1)
                              ans += arr[i];
                       FOI(i, 1, lS){
                              string st = "";
                              FOI(j, 0, lS-1){
                                     if( j == i )
                                         st += zero;
                                     st += arr[j];
                              }
                              if( j == i )
                                  st += zero;
                              if( BIG(st, S) ){
                                  ans = st;
                                  stat = false;
                                  break;
                              }
                       }
                  }while( next_permutation(arr, arr+lS) && stat );
                  zero += "0";
           }
           cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
