import java.math.*;
import java.util.*;
public class GCD2
{
    public static void main(String args[])throws Exception
    {
        //BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
        Scanner in=new Scanner(System.in);
        int t=in.nextInt();
        StringBuffer out=new StringBuffer("");
        for(int i=1;i<=t;i++)
        {
            BigInteger a=new BigInteger(in.next());
            BigInteger b=new BigInteger(in.next());
            if(i!=t)
            out.append(a.gcd(b)+"\n");
            else
            out.append(a.gcd(b));
        }
        System.out.println(out);
       
    }
}
