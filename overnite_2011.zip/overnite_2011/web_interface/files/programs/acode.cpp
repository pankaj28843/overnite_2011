#include<stdio.h>
#include<string.h>

using namespace std;

int main()
{
    int ways[5001],one[5001],two[5001],i,j,l;
    char str[5001];

    while(scanf("%s",str)&&str[0]!='0')
    {
        l=strlen(str);
        for(i=0;i<l;i++)
        one[i]=str[i]-'0';
        for(i=1;i<l;i++)
        two[i]=10*one[i-1]+one[i];

        ways[0]=1;
        ways[1]=(one[1])?1:0;

        if(two[1]>9&&two[1]<27)
        ways[1]++;
        for(i=2;i<l;i++)
        {
            if(one[i])
            ways[i]=ways[i-1];
            else ways[i]=0;
            if(two[i]>9&&two[i]<27)
            ways[i]+=ways[i-2];

        }

        printf("%d",ways[l-1]);
        printf("\n");
    }
    return 0;
}

