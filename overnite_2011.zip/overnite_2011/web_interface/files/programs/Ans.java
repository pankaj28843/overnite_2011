import java.util.Scanner;
import java.io.*;
import java.math.BigInteger;
class Ans
{
	static long gcd(long a,long b)
	{
		if (b==0)
    			return a;
  		else
    			return gcd(b,a%b);
	}
	public static void main(String args[])
	{
		long t;
		Scanner sc=new Scanner(System.in);
		t=sc.nextInt();
		while((t--)>0)
		{
			BigInteger a,b,x;
			a=sc.nextBigInteger();
			b=sc.nextBigInteger();
			int v=b.compareTo(a);
			if(v==0)
			{
				System.out.println(b);
			}
			if(v<0)
			{
				if(b.equals(BigInteger.ZERO))
				{	
					System.out.println(a);
					break;
				}
				x=a.remainder(b);
				long m=x.longValue();
				long n=b.longValue();
				long ans=gcd(m,n);
				System.out.println(ans);
			}
			if(v>0)
			{
				if(a.equals(BigInteger.ZERO))
				{	
					System.out.println(b);
					break;
				}
				x=b.remainder(a);
				long m=x.longValue();
				long n=a.longValue();
				long ans=gcd(m,n);
				System.out.println(ans);
			}
		}

	}
}