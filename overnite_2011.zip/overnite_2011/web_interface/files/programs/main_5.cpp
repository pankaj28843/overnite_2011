#include <iostream>
#include<cstring>
#include<cstdlib>
#include <cstdio>
using namespace std;
long ans;
void permute(char *in)
{
   if(strlen(in)<=1)
   {
       ans++;
       return;
   }

    char temp[3];
    temp[0]=in[0];
    temp[1]=in[1];
    temp[2]='\0';
    int no=atoi(temp);
    if(no<=26)
    {
        permute(in+1);
        permute(in+2);
    }
    else
    {
        permute(in+1);
    }
}
int main()
{
   // freopen("input.in","r",stdin);
   //freopen("output.in","w",stdout);
    char in[5001];
    cin>>in;
    while(strncmp(in,"0",1)!=0)
    {
        ans=0;
        permute(in);
        cout<<ans<<endl;
        cin>>in;
           }
    return 0;
}
