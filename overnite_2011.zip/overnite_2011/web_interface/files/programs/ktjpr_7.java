import java.io.*;

public class ktjpr {
        public static String line;
        public static int j;
        public static int length;
    public ktjpr() {
    }
    
     
     public static long getNodeValue(int s,char path)
     {
     	j++;
     	switch(path)
     	{
     		case 'L':
     		case 'l':		if(j==length)
     							return (s*2);
     					return (getNodeValue(s*2,line.charAt(j)));    					  			
     			
     		case 'P':
     		case 'p':		if(j==length)
     							return s;
     					return getNodeValue(s,line.charAt(j));
     			
     			
     		case 'r':
     		case 'R':		if(j==length)
     							return s*2+1;
     			
     					return (getNodeValue(s*2+1,line.charAt(j)));
     		
     		
     		
     		case '*':  j--;  
     					return (getNodeValue(s,'L')+(getNodeValue(s,'P'))+(getNodeValue(s,'R')));
     				
     		default: System.out.println ("Invalid Path given");
     					return s;		
     		
     	}
     }
    public static void main(String[] args) throws IOException{
       
       DataInputStream br;    
       
       	try{
    	
			br= new DataInputStream(System.in);
			int not;
			line =br.readLine();
			System.out.println (line);
			not=Integer.parseInt(line);
			for(int i=0;i<not;i++)
			{
				int flag;
				line=br.readLine();
				System.out.println ("input=="+line);
				int cost =0;
				long startVal=1;		
				flag=1;
				length = line.length();
				j=0;
				startVal=getNodeValue(1,line.charAt(j));
											
				System.out.println ("cost : " + startVal);			
			}   
       	}
       	catch( IOException ioe )
		  {
			System.out.println(ioe);						
		  }	
		  
		 System.out.println ("");      
       
    }
}