#include<stdio.h>
#include<string.h>

int main()
{
int i,ct,tc,a,bi,wdw,tmp,la,lb;
char bc[252];
scanf("%d",&tc);
for(ct=0;ct<tc;ct++)
{
	scanf("%d",&a);
	la = wdw = 0;
	tmp = a;
	while( tmp>0 )
	{
		tmp /= 10;
		la++;
	}
	scanf("%s",bc);
	if( a==0 )
	{
		printf("%s\n",bc);
		continue;
	}
	lb = strlen(bc);
	for(i=0;i<la;i++)
	{
		wdw *= 10;
		wdw += (bc[i]-48);

	}

	bi = wdw%a;
	for(i=la;i<lb;i++)
	{

		wdw = bi;
		wdw *= 10;
		wdw += (bc[i]-48);
		bi = wdw%a;
	}

	while( bi>0 )
	{
		tmp = a%bi;
		a = bi;
		bi = tmp;
	}
	printf("%d\n",a);
}
return 0;
}
