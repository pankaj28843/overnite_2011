import java.util.*;
public class AlphaCode
{
    public static void main(String args[])throws Exception
    {
        BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
        StringBuffer out=new StringBuffer("");
        String s;
        while(!(s=in.readLine()).equals("0"))
        {            
            int l=s.length();            
            int dp[]=new int[l];char ar[];
            ar=s.toCharArray();
            if(ar[l-1]!='0')
            dp[l-1]=1;            
            for(int j=l-2;j>=0;j--)
            {
                int a=ar[j]-'0',b=ar[j+1]-'0';
                if(j==(l-2)  && (10*a+b)<=26)
                {
                if(a!=0)   
                dp[j]=1+dp[j+1];                
                }                
                else if(j==(l-2) && (10*a+b)>26)
                dp[j]=dp[j+1];
                else if(j!=(l-2) && (10*a+b)<=26)
                {
                    if(a!=0)
                    dp[j]=dp[j+1]+dp[j+2];
                }
                else
                {                    
                    dp[j]=dp[j+1];
                }                
            }
            out.append(dp[0]+"\n");
        }
        System.out.println(out);
    }
}
