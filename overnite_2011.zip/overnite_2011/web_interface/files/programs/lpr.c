#include<stdio.h>
#include<conio.h>
int c,i,j,size,t=0,k,s,p=0;
 char a[50];
 int main()
{
 printf("\n enter the number of test cases\n");
 scanf("%d",&s);
 while(p!=s)
 {printf("\n entr the string\n");
  scanf("%s",&a);
  while(a[size]!='\0')
    size++;
  for(i=0;i<size;i++)
   { if(i==0)
      { if(a[i]=='l')
         c=2;
        else if(a[i]=='r')
         c=3;
        else
         c=1;
         
      }
      else
       { if(a[i]=='l')
          c=2*c;
          else if(a[i]=='r')
           c=2*c+1;
          else
          continue;
       } 
            
   } 
   printf("\n the total cost is = %d\n",c);
   p++;
 }
   getch();
   return 0;    
}
