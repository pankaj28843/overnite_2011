#include<iostream.h>
#include<conio.h>
void main()
{
int gcd(int,int);
int a,b,n,i,arr[1000];
cin>>n;
for(i=1;i<=n;i++)
{
cin>>a>>b;
arr[i]=gcd(a,b);
}
for(i=1;i<=n;i++)
cout<<endl<<arr[i];
getch();
}
int gcd(int a, int b)
{
  if (b==0)
	 return a;
  else
    return gcd(b,a%b);
}