#include<stdio.h>
#include<string.h>
#include<stdlib.h>
long exp(long b,long n,long m)
{
 long x=1;
 long power=b%m;
 while(n!=0)
 {
	if(n%2)
	 x=(x*power)%m;
	power=(power*power)%m;
	n/=2;
 }
 return x;
}
long gcd(long a, long b)
{
  if (b==0)
    return a;
  else
    return gcd(b,a%b);
}

int main()
{
 long num,a;
 char b[251];
 scanf("%ld",&num);
 long i,len,d,rem,j;
 long *res=(long *)malloc(sizeof(long)*num);
 for(i=0;i<num;i++)
 {
  strcpy(b,"");
  scanf("%ld",&a);
  scanf("%s",b);
  len=strlen(b);
  rem=0;
  for(j=0;j<len;j++)
  {
   d=b[j]-'0';
   rem=rem+(d*exp(10,len-1-j,a))%a;
   rem=rem%a;
  }
  res[i]=gcd(a,rem);
 }
 for(i=0;i<num;i++)
  printf("%ld\n",res[i]); 
 free(res);
 return 0;
}