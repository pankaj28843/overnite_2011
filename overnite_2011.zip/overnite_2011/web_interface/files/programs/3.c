#include<stdio.h>

int dividend[250]={0},divstart,divend;
int divisor,myrem;

void my_divide() {
	int i,done=0,temp,iszero;
	int divtemp[250]={0};
	while ( !done ) {
		temp=divisor;
		iszero=1;
		for ( i=divend ; i>=divstart ; i-- ) {
			divtemp[i] = divtemp[i] + dividend[i] - (temp%10);
			iszero*=(divtemp[i]==0 ? 1:0);
			if ( divtemp[i] < 0 ) {
				divtemp[i]+=10;
				divtemp[i-1]--;
			}
			temp /= 10;
		}
		if ( divtemp[0] < 0 || iszero ) {
			done=1;
			for (i=divstart ; i<=divend ; i++ ) myrem=(myrem*10) + dividend[i];
		}else{
			for ( i=divstart ; i<=divend ; i++ ) {
				dividend[i] = divtemp[i];
				divtemp[i]=0;
			}
		}
	}
	return;
}

int main() {
	int test,temp;
	char ch[251];
	scanf("%d",&test);
	while ( test > 0 ) {
		scanf("%d %s",&divisor,ch);
		divstart=1;divend=1;myrem=0;temp=0;
		while ( ch[temp] != '\0'  ) {
			dividend[divend] = ch[temp] - 48;
			divend++;
			temp++;
		}
		divend--;
		my_divide();
		while ( myrem != 0 ) {
			temp=myrem;
			myrem=divisor%myrem;
			divisor=temp;
		}
		printf("%d\n",divisor);
		test--;
	}
	return 0;
}

