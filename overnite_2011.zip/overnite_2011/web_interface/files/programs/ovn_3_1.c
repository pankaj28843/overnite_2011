#include<stdio.h>
#include<string.h>
int count;
void decode(char *a, int start)
{
	int i,n=strlen(a);
	if(start==n)
		{
			count++;
			return;
		}
	if(a[start]=='0')
	return;
	
	 decode(a,start+1);
	 if(start==n-1)
	 return;
 	 if(a[start]=='2'&&a[start+1]>'6')
 	 return;
 	 if(a[start]>'2')
		return;	  
	decode(a,start+2);
}

int main()
{
	
	char a[5000];
	while(1)
	{
		scanf("%s",a);
		if(strcmp(a,"0")==0)
		break;
		count=0;
		decode(a,0);
		printf("%d\n",count);
		
	}
	return 0;
}