import java.util.Scanner;
class fire2
{
   public static void main(String args[])
   {
        Scanner sc=new Scanner(System.in);
        String st=sc.next();
        
        int val=recur(st,0,1);
        System.out.println(val);
    }
    static int v1,v2,v3,y;
    static char ch;
    public static int recur(String st,int p,int val)
    {
        ch=st.charAt(p);
        if(p==st.length()-1)
        {
            if(ch=='L')return 2*val;
            else if(ch=='R')return 2*val+1;
            else if(ch=='P')return val;
            else
            {
                return 5*val+1;
            }
        }
        else
        {
            if(ch=='L')val=2*val;
            else if(ch=='R')val=2*val+1;
            else if(ch=='P')val=val;
            else
            {
                int p1,p2,p3;
                p1=p2=p3=++p;
                
                v1=recur(st,p1,2*val);
                v2=recur(st,p2,2*val+1);
                v3=recur(st,p3,val);
                
                return v1+v2+v3;
            }
        }
        y=recur(st,++p,val);
        return y;
    }
}