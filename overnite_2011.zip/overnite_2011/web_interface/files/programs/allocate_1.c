#include<stdio.h>
#include<stdlib.h>

int main()
{
	int *arr;
	while(1)
		arr=(int*)calloc(10000,sizeof(int));
	return 0;
}
