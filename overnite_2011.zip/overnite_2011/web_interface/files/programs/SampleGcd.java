import java.lang.*;
import java.util.Scanner;

class SampleGcd
{
	public static void main(String[] args) 
	{
		int num1;
		double num2;
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		int gcd[] = new int[num];
		for(int i=0; i<num; i++)
		{
			num1 = scan.nextInt();
			num2 = scan.nextDouble();
			gcd[i] = (int)gcd(num1, num2);
		}
		System.out.println("\nOutput:");
		for(int i=0; i<num; i++)
			System.out.println(gcd[i]);
		
	}
	static double gcd(double m, double n)
	{
		if (m == 0 && n == 0)
			return(-1);

		if (m < 0) m = -m;
		if (n < 0) n = -n;

		if (m == 0)
			return (n);
		else if (n == 0)
			return (m);
		else
			return gcd(n, m % n);
	}
}
