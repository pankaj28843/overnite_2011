#include<stdio.h>
#include<string.h>
#include<stdlib.h>
long long int count;
void permute(char * str)
{
	if(str[0]=='\0'||str[0]=='0')
	{
		count++;
		return;
	}
	char ch=str[0];
	char *temp_str;
	temp_str=malloc((strlen(str)-1)*sizeof(char));
	strcpy(temp_str,str+1);
	permute(temp_str);
	if(temp_str[0]!='\0')
	{
		if(ch=='1')
		{
			char *_temp_str;
			_temp_str=malloc((strlen(str)-2)*sizeof(char));
			strcpy(_temp_str,str+2);
			permute(_temp_str);
			return;
		}
		else if(ch=='2' && temp_str[0]<='6')
		{
			char *_temp_str;
			_temp_str=malloc((strlen(str)-2)*sizeof(char));
			strcpy(_temp_str,str+2);
			permute(_temp_str);
			return;
		}
	}
	return;
}
int main()
{
	count=0;
	char input[5000];
	scanf("%s",input);
	while(strcmp(input,"0\0"))
	{
		permute(input);
		printf("%lld\n",count);
		count=0;
		scanf("%s",input);
	}
	return;
}

				
