#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	int i,j,test;
	scanf("%d",&test);
	for(i=0;i<test;i++)
	{
		char num2[300],num1[10];	
		int num=0,dividend,r=0;
		scanf("%s%s",num1,num2);
		getchar();
		int len=strlen(num2);
		int len1=strlen(num1);
		for(j=0;j<len1;j++)
			num=10*num+(num1[j]-'0');
		if(num==0)
		{
			printf("%s\n",num2);
			continue;
		}
		for(j=0;j<len;j++)
		{
			dividend=r*10+(num2[j]-'0');
			r=dividend%num;
		}
		int a=num,b=r;
		while(b!=0)
		{
			r=a%b;
			a=b;
			b=r;
		}
		printf("%d\n",a);
	}
	printf("\n");
	return 0;
}

