#include<iostream>
#include <cstring>
#include <cstdio>
using namespace std;

int ans;
bool check(char* s,int size,int div)
{
    if(size/div==0)
    return true;
    if(size%div!=0)
    return check(s,size,div+1);
    int flag=false;
    for(int i=1;i<div;i++)
    {
        if(strncmp(s,s+i*(size/div),(size/div))!=0)
        {
            flag=true;
            break;
        }
    }
    if(flag==false)
    return false;
    return check(s,size,div+1);
}
void permute(char *s,int size,int x)
{
    if(x==0)
    {
        if(check(s,size,2)==true)
        ans=(ans+1)%531169;
        return;
    }
    for(int i=0;i<size;i++)
    {
        if(s[i]=='0')
        {
            s[i]=1;
            permute(s,size,x-1);
            s[i]='0';

        }
    }
}
int fact(int x)
{
   int f=1;
   while(x!=1)
   {
       f=(f*x)%531169;
       x--;
   }
   return f;
}
int main()
{
   // freopen("input.in","r",stdin);
    //freopen("output.in","w",stdout);

    int test;
    cin>>test;
    char * s;
    while(test--)
    {
        ans=0;
        int x,y,lastz,startx;
        cin>>x>>y;
        s=new char[x+y];
        memset (s,'0',x+y);
        lastz=x+y-1;
        startx=x-1;
        permute(s,x+y,x);
        cout<<ans/fact(x)<<endl;
        delete[] s;
    }
    return 0;
}
