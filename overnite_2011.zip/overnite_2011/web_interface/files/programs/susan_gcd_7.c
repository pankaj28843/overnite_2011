#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	int i,j,test;
//	int *result;
	scanf("%d",&test);
//	result=(int*)calloc(test*sizeof(int));
	for(i=0;i<test;i++)
	{
//		printf("%d",i);
		char num2[300];	
		int num1,dividend,r=0;
		scanf("%d%s",&num1,num2);
		int len=strlen(num2);
		if(num1==0)
		{
			printf("%s\n",num2);
			continue;
		}
		for(j=0;j<len;j++)
		{
			dividend=r*10+num2[j]-'0';
			r=dividend%num1;
		}
		int a=num1,b=r;
		while(b!=0)
		{
			r=a%b;
			a=b;
			b=r;
		}
		printf("%d\n",a);
	}
	printf("\n");
	return 0;
}










