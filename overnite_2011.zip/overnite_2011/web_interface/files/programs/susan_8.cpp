#include<iostream.h>

//using namespace std;
class susan_gcd
{
public:
  int size;
  unsigned short int *a;
  long int *b;
  susan_gcd();
  int gcd(int x,int y);
};
susan_gcd::susan_gcd()
{
 cin>>size;
  a=new unsigned short int(size);
  b=new long int(size);
  for(int i=0;i<(size);i++)
  {
	 cin>>a[i];
	 cin>>b[i];
	}
}
int susan_gcd::gcd(int x,int y)
{
  if (y==0)
	 return x;
  else
	 return gcd(y,x%y);
}
int main()
{
int result;
  susan_gcd obj;
  for(int i=0;i<(obj.size);i++)
  {
	 result=obj.gcd(obj.a[i],obj.b[i]);
	 cout<<result<<endl;
	}
	return 0;

}