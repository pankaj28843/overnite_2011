#include<cstdio>
#include<cstring>
#define N 5001
int dp[N+1],n;
char a[N+5];

int fn(int i)
{
if(i==n) return 1;
int y=0,z=0;
if(dp[i]>=0) return dp[i];
if(a[i]>'0') y=fn(i+1);
int x=10*(a[i]-'0')+a[i+1]-'0';
if(x<=26&&x>0) z=fn(i+2);
return dp[i]=y+z;
}


int main()
{
while(1)
{
gets(a);
if(a[0]=='0') break;
n=strlen(a);
memset(dp,-1,sizeof(dp));
printf("%d\n",fn(0));

}

}
