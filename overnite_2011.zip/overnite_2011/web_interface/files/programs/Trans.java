import java.io.*;
class Trans
{
    static int cnt=0;
    public static void main(String args[])throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        String s;
        while(!(s=br.readLine()).equals("0"))
        {
            cnt=0;
            if(check1(s))
            {
                cnt=cnt+1;
            }
            check2(s);
            System.out.println(cnt);
        }
    }
    public static boolean check1(String s)
    {
        char ch;
        int i;
        for(i=0;i<s.length();i++)
        {
            ch=s.charAt(i);
            if(ch=='0')
                return false;
        }
        return true;
    }
    public static void check2(String s)
    {
        int i,len=s.length();
        String word,next;
        if(len==1)
        {
            if(check1(s))
                cnt++;
        }
        else if(len==2)
        {
            if(Integer.parseInt(s)<=26)
            {
                cnt++;
            }
        }
        else if(len!=0)
        {
            for(i=0;i<len-2;i++)
            {
                word=s.substring(i,i+2);
                next=s.substring(i+2);
                if(Integer.parseInt(word)<=26)
                {
                    if(check1(next))
                        cnt++;
                    check2(next);
                }
            }
        }
    }
}