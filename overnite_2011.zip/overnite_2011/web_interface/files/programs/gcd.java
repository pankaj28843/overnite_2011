import java.math.BigInteger;
//import java.io.*;
import java.util.Scanner;
class gcd
{
    public static void main(String args[])
    {
//        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
  //      int i,input=Integer.parseInt(br.readLine());
        Scanner sc =new Scanner(System.in);
        int i,input=sc.nextInt();
        BigInteger ans,a,b;
        for(i=1;i<=input;i++)
        {
            a=new BigInteger(sc.next());
            b=new BigInteger(sc.next());
            ans=gcd(a,b);
            System.out.println(ans);
        }
    }
    public static BigInteger gcd(BigInteger a, BigInteger b)
    {
        if (b.compareTo(new BigInteger("0"))==0)
            return a;
        else
            return gcd(b,a.remainder(b));
    }
}