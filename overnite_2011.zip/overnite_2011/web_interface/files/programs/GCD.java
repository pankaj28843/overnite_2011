import java.math.BigInteger;
import java.io.*;

class gcd1{

	public static void main(String arg[]) throws IOException
	{
		BigInteger a,b;
		String str;
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter first Number...");
		str=br.readLine()
		a= new BigInteger(str);
		System.out.println("Enter second Number...");
		str=br.readLine()
		b= new BigInteger(str);
		System.out.println("The GCD is....." + gcd(a,b));
	}

	BigInteger gcd(BigInteger a, BigInteger b)
	{
  		if (b==0)
    			return a;
  		else
    			return gcd(b,a%b);
	}
}
