#include<iostream>
#include<conio.h>

using namespace std;

int main()
{long long int a[500][2],b[500];
 long long int n,p,q,r,s,j,i,h;
 cout<<"\n"<<" enter the number of lines:";
 cin>>n;
 for(i=0;i<n;i++)
 {
   cin>>a[i][0];
   cin>>a[i][1];
 }
 for(i=0;i<n;i++)
 { 
   for(j=a[i][0];j>=1;j--)
    {p=a[i][0]/j;
     q=a[i][1]/j;
     r=a[i][0]-p*j;
     s=a[i][1]-q*j;
     if(r==0&&s==0)
     break;
    }
  b[h]=j;
  h++;
}


cout<<"the output set is:"<<"\n";
for(i=0;i<n;i++)
cout<<b[i]<<"\n";
getch();
return(0);

}
        
   
 
