#include<stdio.h>
#include<stdlib.h>
long gc(long a,long b)
{
  if (b==0)
    return a;
  else
    return gc(b,a%b);
}
int main()
{
    int i,l,t;long a,r;char s[260],s1[2];
    scanf("%d",&t);
    while(t--)
    {r=0;

    scanf("%ld %s",&a,s);
    l=strlen(s);
    if(a!=0)
    {for(i=0;i<l;i++)
    {   strncpy(s1,s+i,1);
        r=((r*10)+atoi(s1))%a;


    }

    printf("%ld\n",gc(a,r));
    }
    else
    printf("%s\n",s);
    }
}


