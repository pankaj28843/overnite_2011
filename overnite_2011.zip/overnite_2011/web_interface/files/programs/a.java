import java.util.*;
import java.lang.Number.*;
import java.math.*;
class a
{static String b,c;
	
	public static void main(String s[])
	{
		System.out.println("enter the 2 no.");

		Scanner scan = new Scanner(System.in);
		
		b = scan.nextLine();
		c = scan.nextLine();
		
		BigInteger x= new BigInteger(b);
		BigInteger y= new BigInteger(c);
		System.out.print(gcd(x,y));
	}	
static BigInteger  gcd(BigInteger a, BigInteger b)
{
	//System.out.print(a);
	if(b.compareTo(BigInteger.valueOf('0'))<0)
	return a;
	else
	//{System.out.println(a.remainder(b));
	return gcd(b,a.remainder(b));
}


	}


	
