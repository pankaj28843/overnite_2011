#include<stdio.h>
#include<conio.h>
#include<math.h>

//int gcd(int,int);

void main()
{
	long int a,b,x,y;
	int i,n;
	y=pow(10,250);
	printf("Enter no. of lines 2 be followed");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{  printf("Enter the value of a & b respectively");
		scanf("%l%l",&a,&b);
		if((a>=0 && a<=40000)
			{if(b>=a && b<y)
				{ x=gcd(a,b);
				  printf("Result is %l ",x);
				}
			}

	}
}

int gcd(long int a, long int b)
{
  if (b==0)
    return a;
  else
    return gcd(b,a%b);
}
