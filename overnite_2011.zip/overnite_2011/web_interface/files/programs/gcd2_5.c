#include<stdio.h>
#include<string.h>
int main(){
	int t,small,i,tmp,new;
	char num[255];
	scanf("%d",&t);
	while(t!=0){
		t--;
		new=0;
		scanf("%d",&small);
		scanf("%s",num);
		if(small==0){
			printf("%s\n",num);
			continue;
		}
		else if(small==1){
			printf("1\n");
			continue;
		}
		int len=strlen(num);
		for(i=0;i<len;i++){
			new=(new * 10)+(num[i]-48);
			new=new%small;
		}
		if(new==0)
		{
			printf("%d\n",small);
			continue;
		}
		int big=0,temp=0;
		temp=small;
		small=new;
		big=temp;
		while(small!=0){
			tmp=big%small;
			big=small;
			small=tmp;
		}
		printf("%d\n",big);
	}
	return 0;
}
