import java.io.* ;

/*
 * input.txt
 *
 * 2
 * 4000 30000
 * 40000 10000000000000000000000000000000000000000000000000000000000
 *
 */

public class SusanGCD
{
	private FileInputStream fis ;
	private BufferedReader br ;
	private String totalInput ;

	public SusanGCD ( )
	{
		fis = null ;
		br = null ;
		try
		{
			br = new BufferedReader ( new InputStreamReader ( ( fis = new FileInputStream ( "input.txt" ) ) )  ) ;
		}
		catch ( IOException ioe )
		{
			System.out.println ( "Err." ) ;
		}
	}
	
	public void getInput ( )
	{
		int total = 0;
		
		FileOutputStream fos = null ;
		BufferedWriter bw = null ;
		
		try
		{
			bw = new BufferedWriter ( new OutputStreamWriter ( fos = new FileOutputStream ( "output.txt" ) ) ) ;
		}
		catch ( IOException ioe )
		{
			System.out.println ( "Unable to write.." ) ;
		}
		
		try
		{
			totalInput = br.readLine() ;
			total = Integer.parseInt( totalInput ) ;
		}
		catch ( NumberFormatException nfe ) {
			System.exit( 0 ) ;
		}
		catch ( IOException ioe )
		{
			System.out.println ( "err.. Missing Input.." ) ;
			System.exit( 0 ) ;
		}
		
		for ( int i = 0 ; i < total ; i ++ )
		{
			String num1="" , num2="" , res = "" ;
			try
			{
				String input = br.readLine() ;
				num1 = input.split( " " )[0] ;
				num2 = input.split( " " )[1] ;
				if ( num1.length() > num2.length() )
				{
					String temp = num1 ;
					num1 = num2 ;
					num2 = temp ;
				}
				else if ( num1.length() == num2.length() )
				{
					if ( num1.compareTo( num2 ) > 0 )
					{
						String temp = num1 ;
						num1 = num2 ;
						num2 = temp ;
					}
				}
				
				System.out.println ( res = result( num1 , num2 )) ;
			}
			catch ( IOException ioe ) {
				System.out.println ( "err" ) ;
			}
			try{
				res = result( num1, num2 ) ;
				bw.write( res + "\n" ) ;}
			catch ( IOException ioe ) { 
			}
		}
		try {
		bw.close() ;
		fos.close() ;
		
		br.close() ;
		fis.close ( ) ;
		}catch ( IOException ioe ){
			System.out.println ( "Closing Error." ) ;
		}
	}

	private int gcd_test ( int a , int b)
	{
		if ( b == 0 )
			return a ;
		else return gcd_test( b, a%b ) ;
	}
	
	public String gcd ( String num1 , String num2 ) // 1<num1<40000 
	{
		String str = num2.substring( 0 , num1.length() ) ;
		int size = num1.length() ;
		int ii = Integer.parseInt( str ) ;
		int j = Integer.parseInt( num1 ) ;
		int temp = 0 ;
		
		for ( int i = size ; i <= num2.length() ; i++ ) 
		{
			temp = ii % j ;
			str = String.valueOf( temp ) ;
			if ( i >= num2.length() )
				break ;
			str += num2.substring( i , i+1 ) ;
			ii = Integer.parseInt( str ) ;
		}
		return  String.valueOf( temp ) ;
	}
	
	private String result ( String num1, String num2 )
	{
		String num = gcd ( num1 , num2 ) ;
		return String.valueOf(gcd_test( Integer.parseInt(num) , Integer.parseInt(num1) ) ) ;
	}
	
	public static void main (String[] args) 
	{
		int num = 0 ;
		try{
			DataInputStream ds = new DataInputStream ( System.in ) ;
			System.out.println ( "Enter the number of lines : " ) ;
			String number = ds.readLine() ;
			num = Integer.parseInt( number ) ;
			BufferedWriter bw1 = new BufferedWriter ( new OutputStreamWriter ( new FileOutputStream ( "input.txt" ) ) ) ;
			bw1.write( number ) ;
			String num1, num2 ;
			for ( int i = 0 ; i < num ; i ++ ){
				System.out.println ( "Enter the " + i + " th A :" ) ;
				num1 = ds.readLine() ;
				System.out.println ( "Enter the " + i + " th B :" ) ;
				num2 = ds.readLine() ;
				bw1.write( "\n" + num1 + " " + num2 ) ;
			}
			bw1.close() ;
		}
		catch ( IOException ioe ){
		}
		catch ( NumberFormatException nfe ) {
			System.exit(0) ;
		}
		SusanGCD t = new SusanGCD ( ) ;
		System.out.println ( "Output:" ) ;
		t.getInput( ) ;
	}
}

/*
 * output 
 *
 * 2000
 * 40000
 *
 */