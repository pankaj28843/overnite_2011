#include<stdio.h>
char a[5001];
int res=0,num;
void func(int count,int len,int count1)
{
	if(count1==count)
	{
		if(len==1)
		   res++;
		if(len==2)
		{
		    num=(a[count-2]-48)*10+(a[count-1]-48);
		    if(num<=26)
			    res++;
		}
		return;
	}
	else
	{
		func(count,1,count1+1);
		if(count1<=count-2)
		{
		  num=(a[count1]-48)*10+(a[count1+1]-48);
		  if(num<=26)
		  func(count,2,count1+2);
		}
		return;
	}
}
int main()
{
	char c;
	int count;
	while(1)
	{
		count=0;
	    scanf("%c",&c);
	    if(c==48)
		    break;
            while(1)
     	    {
		if(c=='\n')
			break;
		a[count]=c;
		count++;
		scanf("%c",&c);
            }
	    func(count,1,0);
	    printf("%d\n",res);
	    res=0;
	}
	return 0;
}
		

