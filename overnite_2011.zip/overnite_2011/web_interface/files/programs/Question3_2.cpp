#include<iostream.h>
#include<conio.h>

void main()
{
     int a,b,n, counter;
     cin>>n;
     while(n!=0)
     {
                counter = 0;
               a=n;
               b=n; 
               while(a>0)
               {
                       counter++;
                       a=a/10;
               }
               while(b>=10)
               {
                           if(((b/10)%10==1)||((b/10)%10==2))
                           counter++;
                           b=b/10;
               }
               cout<<counter;
               cin>>n;
     }
}
