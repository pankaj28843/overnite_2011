import java.util.*;
import java.math.*;
class a
{static String b,c;
	
	public static void main(String s[])
	{
		Scanner scan = new Scanner(System.in);
		int l=scan.nextInt();
		while(l>0)
		{//System.out.println("enter the 2 no.");
		b = scan.next();
		c = scan.next();
		BigInteger x= new BigInteger(b);
		BigInteger y= new BigInteger(c);
		System.out.println(gcd(x,y));
		l--;
		}
		
	}	
public static BigInteger  gcd(BigInteger a, BigInteger b)
{
	//BigInteger p= BigInteger.ZERO;
	//System.out.println("first"+a);
	//System.out.println("sec"+b);
	if(b.equals(BigInteger.ZERO))
	return a;
        //else if(a.compareTo(BigInteger.valueOf('0'))==0)
	//p= b;
        else
        return gcd(b,a.remainder(b));
        //return p;
	
	
}


	}


	
