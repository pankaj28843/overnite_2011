#include<stdio.h>
#include<string.h>
 
int main()
{
int i,ct,tc,a,bi,wdw,tmp,la,lb;
char bc[252];
scanf("%d",&tc);
for(ct=0;ct<tc;ct++)
{
	scanf("%d",&a);
	la = wdw = 0;
	tmp = a;
	while( tmp>0 )
	{
		tmp /= 10;
		la++;
	}
	scanf("%s",bc);
	if( a==0 )
	{
		printf("%s\n",bc);
		continue;
	}
	lb = strlen(bc);
	for(i=0;i<la;i++)
	{
		wdw *= 10;
		wdw += (bc[i]-48);
//		printf(" %d ",wdw);
	}
//	printf("%d\t%d\t%d",lb,la,wdw);
	bi = wdw%a;
	for(i=la;i<lb;i++)
	{
//		printf("\t%d\t%d\t%d\n",wdw,a,bi);
		wdw = bi;
		wdw *= 10;
		wdw += (bc[i]-48);
		bi = wdw%a;
	}
//	printf("\t%d\t%d\t%d\n",wdw,a,bi);
	while( bi>0 )
	{
		tmp = a%bi;
		a = bi;
		bi = tmp;
	}
	printf("%d\n",a);
}
return 0;
}