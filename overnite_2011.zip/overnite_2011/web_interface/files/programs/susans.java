import java.io.*;
class susans
{
InputStreamReader isr=new InputStreamReader(System.in);
BufferedReader br=new BufferedReader(isr);
public void f()throws IOException
{
int i,j;
String s,s1="",s2;
char ch;
int n=Integer.parseInt(br.readLine());
double ar[]=new double[n];double a=0,b=0;
for(i=0;i<n;i++)
{s1="";
s=br.readLine();
for(j=0;j<s.length();j++)
{
ch=s.charAt(j);
if(ch==' ')
{
a=Double.parseDouble(s1);
s1=s.substring(j+1,s.length());
b=Double.parseDouble(s1);
break;
}
else
s1=s1+ch; 
}
ar[i]=(gcd(a,b));
}
for(i=0;i<n;i++)
{
s1=Double.toString(ar[i]);
s2=s1.substring(0,(s1.length()-2));
System.out.println(s2);
}
}
double gcd(double a,double b)
{
if(b==0)
return a;
else 
return gcd(b,a%b);
}
}