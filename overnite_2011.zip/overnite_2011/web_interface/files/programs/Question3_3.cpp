#include<iostream.h>

int main()
{
     int a,b,n, counter;
     cin>>n;
     while(n!=0)
     {
					counter = 0;
               a=n;
					b=n;
					while(a>0)
               {
                       counter++;
                       a=a/10;
					}
               while(b>=10)
               {
									if(((b/10)%10==1)||(((b/10)%10==2)&&(b/10)<7&&(b/10)>0))
									counter++;
									b=b/10;
               }
					cout<<counter<<endl;
               cin>>n;
     }
     return 0;
}
