public class translator
{
String ar[]={"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26"};
String ar1[]={"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
int c=0;
public void possiblestrings(String s,String rtn)
{
if(s.length()==0)
{
c++;
return;
    }
    String ps="",ms="";
    for(int i=0;i<26;i++)
    {
        if(s.startsWith(ar[i]))
        {
            ps=rtn+ar1[i];
            ms=s.replaceFirst(ar[i],"");            
            possiblestrings(ms,ps);

        }
    }
}



public void main(String ms)
{
possiblestrings(ms,"");
System.out.println(c);
c=0;
    }
    
    
    
    
    
    public void main1(String a[])
      {
       int i;
       for(i=0;i<a.length;i++)
       {
           String s=a[i];
           if(a[i]!="0")
           {
               main(s);
               
            }
            else
            break;
        }}
    
    
} 
    



               