#include<iostream>
#include<vector>
using namespace std;
int gcd(int a, int b)
{
  if (b==0)
    return a;
  else
    return gcd(b,a%b);
}
int main()
{
    int n,i;
    cin>>n;
    vector <int> ans;
    for(i=0;i<n;i++){
       int a,b;
       cin>>a>>b;
       ans.push_back(gcd(a,b));
    }
    for(i=0;i<ans.size();i++)
    {
      cout<<ans[i];
      if(i!=(ans.size()-1))cout<<"\n";
    }
    cin>>n;
}

