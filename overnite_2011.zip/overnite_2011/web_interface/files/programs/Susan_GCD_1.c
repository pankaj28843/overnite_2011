#include<stdio.h>
#include<stdlib.h>

int gcd(int a,int b)
{
	if(b==0)return a;
	else return gcd(b,a%b);
}

void main()
{
	int i,n,hcf;
	scanf("%d",&n);
	int *num1,*num2;
	num1 = (int *)malloc(n*sizeof(int));
	num2 = (int *)malloc(n*sizeof(int));
	for(i=0;i<n;i++)
	{
		scanf("%d %d",&num1[i],&num2[i]);
	}

	for(i=0;i<n;i++)
	{
		hcf=gcd(num2[i],num1[i]);
		printf("%d\n",hcf);
	}
}
