This file should have been downloaded from http://www.dll-downloads.com
If this file was not downloaded form DLL-Downloads.com, please let us know as soon as possible.

 e-mail:	webmaster@webpromo-inc.com
website:	http://www.dll-downloads.com

We're glad you have chosen DLL-Downloads.com for computer & technology news, help and downloads.  It would be wonderful to show your appreciation by donating a mere $3.00 to help maintain the site.  If you have a credit card or PayPal account you may donate funds by clicking on the Support/Donate link on our website.  

Installation Notes:
Using a ZIP decompression tool, extract the file to your computer in the directory C:\windows\system OR C:\WINNT\system32.
Where drive 'C' is the hard drive letter of your Windows based operating system.

If you don't have a ZIP decompression utility, you can download WinZip from our website at http://www.dll-downloads.com
If you have any problems, please see our FAQs page at http://www.dll-downloads.com

For all other technical support issues please visit our sister site MyBootDisks.com at http://www.mybootdisks.com

Thank you for visiting DLL-Downloads.com