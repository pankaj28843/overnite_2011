#include <iostream>
#include <cmath>
using namespace std;
int main() {
    int T; scanf("%d",&T); while (T--) {
        int A; scanf("%d",&A);
        char B[1000]; scanf("%s",B);
        if (A==0) {
            printf("%s\n",B);
            continue;
        }
        int ret = 0;
        for (int i=0; B[i]; i++) {
            ret = (10*ret + B[i]-'0')%A;
        }
        while (ret!=0) {
            int tmp = A%ret;
            A = ret;
            ret = tmp;
        }
        printf("%d\n",A);
    }
}