#include <iostream>
#include <string>

using namespace std;

unsigned long calculate (string);
unsigned long ctr=0;

int main()
{
  string input;

  while(1)
    {
      cin>>input;
      if(input.at(0) =='0') break;
      cout<<calculate(input)<<endl;
  }
  return 0;
}

unsigned long calculate(string str)
{
  if(str.length()<=1) return 1;
  bool two = str[0]<='2' && str[1]<='6';
  if(two) return calculate(str.substr(1))+ calculate(str.substr(2));
  else return calculate(str.substr(1));	             
}

  
  
