import java.math.*;
import java.io.*;
import java.util.*;
public class GCD2
{
    public static void main(String args[])throws Exception
    {
        BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
        int t=Integer.parseInt(in.readLine());
        StringBuffer out=new StringBuffer("");
        for(int i=1;i<=t;i++)
        {
            StringTokenizer s=new StringTokenizer(in.readLine());
            BigInteger a=new BigInteger(s.nextToken());
            BigInteger b=new BigInteger(s.nextToken());
            out.append(a.gcd(b)+"\n");
        }
        System.out.println(out);
    }
}
