#include <cstdio>
#include <algorithm>
#include <cmath>
using namespace std;

int gcd(int a,int b)
{
	int r;
	while(b!=0)
	{
		r = a%b;
		a = b;
		b = r;	
	}
	return a;
}

int main()
{
	int t, a, g, b, i;
	char ca[260];
	for(scanf("%d",&t);t--;)
	{
		scanf("%d %s",&a,ca);
		b=0; i=0;
		
		if(a==0)
		{
			printf("%s\n",ca);
			continue;
		}
		
		while('0'<=ca[i] && ca[i]<='9') b = (b*10+(ca[i++]-'0'))%a;
		g = gcd(a,b);
		printf("%d\n",g);
	}
	return 0;
}
