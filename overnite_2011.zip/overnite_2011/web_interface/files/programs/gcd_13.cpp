#include<iostream>
using namespace std;
int main()
{
    long long gcd(long long,long long);
    char A[300];
    long long b,test,i,j,a[300],count=0;
    cin>>test;
    while(test>0)
    {
                 cin>>b;
                 cin>>A;
                 count=0;
                 long long s=0,rem,x=0;
                 for(i=0;A[i]!='\0';i++)
                 {
                                     a[i]=A[i]-48;
                                     count++;
                 }
                 while(x<count)
                 {
                     for(i=x;i<count;i++)
                     {
                             s=s*10+a[i];            
                             if(s>=b)
                             {break;}
                     }
                     x=i+1;
                     rem=s%b;
                     s=rem;
                 }
                 
                 if(rem==0)
                 {
                           cout<<b<<endl;
                 }
                 else
                 {
                     s=b;
                     b=rem;
                     cout<<gcd(s,b)<<endl;
                 }
                 test--;
    }
    return 0;
}
long long gcd(long long x, long long y)
{
  if (y==0)
    return x;
  else
    return gcd(y,x%y);
}
