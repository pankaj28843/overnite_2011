#include<cstdio>
int gcd(int a,int b)
{
        if(b==0)
                return a;
        return gcd(b,a%b);
}
long long ncr[110][110],npr[110][110];
void initialize()
{
        int i,j;
        int fact[110];
        fact[0]=1;
        for(i=0;i<110;++i){
                ncr[i][0]=1;ncr[i][1]=i;}
        for(i=1;i<110;++i)
        {
                for(j=2;j<=i;++j)
                        {
                        ncr[i][j]=(ncr[i-1][j-1]+ncr[i-1][j])%531169;}
        }
        
}                
int main()
{
        initialize();
        int t,a,b,d,s,s2,i;
        scanf("%d",&t);
        while(t--)
        {
                scanf("%d%d",&a,&b);
                d=gcd(a,b);
                s=0;
                if(d!=1){
                for(i=2;i*i<d;++i)
                {
                        if(d%i==0)
                        {
                                s=(s+(ncr[(a+b)/i][a/i]))%531169;
                                s2=d/i;
                                s=(s+ncr[(a+b)/s2][a/s2])%531169;
                        }              
                
                }
                if(d%i==0)
                {
                        s=(s+(ncr[(a+b)/i][a/i]))%531169;
                }
                if(d!=i)
                        s=(s+(ncr[(a+b)/d][a/d]))%531169;}
                s=(ncr[a+b][a]-s+531169)%531169;
                printf("%d\n",s);
        }
        return 0;
}
