import java.io.*;
import java.math.BigInteger;
class hcf2
{
    public static void main(String args[])throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        
        String in=br.readLine();
        long i,max=Long.parseLong(in);
        String a[]=new String[2];
        int j,k=0;
        BigInteger p,q;
        char ch;
        for(i=1;i<=max;i++)
        {
            in=br.readLine();
            k=0;
            a[0]="";
            a[1]="";
            for(j=0;j<in.length();j++)
            {
                ch=in.charAt(j);
                if(ch!=' ')
                {
                    a[k]=a[k]+ch;
                }
                else
                {
                    k++;
                }
            }
            p=new BigInteger(a[0]);
            q=new BigInteger(a[1]);
            System.out.println(gcd(p,q));
        }
    }
    public static BigInteger gcd(BigInteger a, BigInteger b)
    {
        if(a.compareTo(new BigInteger("0"))==0)return b;
        if (b.compareTo(new BigInteger("0"))==0)
            return a;
        else
            return gcd(b,a.remainder(b));
    }
}