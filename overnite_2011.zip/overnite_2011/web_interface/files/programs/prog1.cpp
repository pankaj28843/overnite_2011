#include<iostream>
using namespace std;
 char b[250];
 
int euc_gcd(int x,int y)
{
    if (y==0)
    return x;
else return
euc_gcd(y,x%y);
}
int mygcd(int a,char *b)
{
 int val=0,i=0,y=0;
 
 while(*(b+i)!=NULL)
 {
 y=(y*10+*(b+i)-'0')%a;i++;
 
 
 }
 
 return euc_gcd(a,y);
}
 
int main()
{
 int t,a,x,i;
 
 cin>>t;
 for(i=0;i<t;i++)
{
 scanf("%d %s",&a,b);
 if(a==0)
 printf("%s\n",b);
 else
 {
 x=mygcd(a,b);
 cout<<x<<endl;
 
 }
}
return 0;
}
