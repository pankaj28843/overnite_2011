#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

#define MAXNO 100 
#define EXCH(X,Y,Z) ((Z)=(X), (X)=(Y), (Y)=(Z))
void selectionSort(int [], int);
int main() // main.c
{
    while (1);
    return 0;
}
