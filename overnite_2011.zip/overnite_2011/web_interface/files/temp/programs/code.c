#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>


#define EXCH(X,Y,Z) ((Z)=(X), (X)=(Y), (Y)=(Z))
void selectionSort(int [], int);
int main() // main.c
{
    int no , i,j,max,sum ;
    int *data ;
 
    scanf("%d",&no);
    if((no%2)==0)
    {
      data=(int*)malloc(no*sizeof(int));
      for(i=0;i<no;i++)
       scanf("%d", &data[i]);
    }
    else
    {
       data=(int*)malloc((no+1)*sizeof(int));
       data[no]=0;
       for(i=0;i<no;i++)
         scanf("%d", &data[i]);
       no=no+1;

    }
    selectionSort(data, no) ;
    i=1;
    j=no-2;
    max=data[0]+data[no-1];
    while(i<j)
    {
      sum=data[i]+data[j];
      if(sum>max)
        max=sum;
      i++;
      j--;
    }
    printf("%d",max);
    return 0 ;
}

void selectionSort(int data[], int nod)
 { 
     int i ;
     		
     for(i = 0; i < nod - 1; ++i) {
         int max, j ;
         int temp ;

         temp = data[i] ;
         max = i ;
         for(j = i+1; j < nod; ++j)
             if(data[j] > temp) {
                temp = data[j] ;
                max = j ;
             }
         EXCH(data[i], data[max], temp);
     }
}

