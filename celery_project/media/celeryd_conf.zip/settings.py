import djcelery
djcelery.setup_loader()
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql', 
        'NAME': 'overnight',                  
        'USER': 'public',                     
        'PASSWORD': 'rohan',                  
        'HOST': '10.106.6.108',          
        'PORT': '',                     
    }
}
TIME_ZONE = 'Asia/Kolkata'
INSTALLED_APPS = (
    'djcelery',
    'main',
)

BROKER_HOST = "10.106.6.108"
BROKER_PORT = 5672
BROKER_USER = "rohan"
BROKER_PASSWORD = "rohan"
BROKER_VHOST = "myvhost"
