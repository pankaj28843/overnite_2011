import djcelery
djcelery.setup_loader()
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql', 
        'NAME': 'overnight',                  
        'USER': 'public',                     
        'PASSWORD': 'rohan',                  
        'HOST': 'localhost',          
        'PORT': '',                     
    }
}
TIME_ZONE = 'Asia/Kolkata'
INSTALLED_APPS = (
    'djcelery',
    'main',
)

BROKER_HOST = "localhost"
BROKER_PORT = 5672
BROKER_USER = "rohan"
BROKER_PASSWORD = "rohan"
BROKER_VHOST = "myvhost"
