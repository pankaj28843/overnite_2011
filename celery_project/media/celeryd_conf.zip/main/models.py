from django.db import models
from django.forms import ModelForm
from django import forms
from picklefield import PickledObjectField
from django.contrib.auth.models import User
#The programming problem
class Problem(models.Model):
    title = models.CharField('Title', max_length = 100)
    question = models.TextField('Question')
    def __unicode__(self):
        return self.title
    
#Input Output file for problem
class InputOutput(models.Model):
    problem = models.ForeignKey(Problem)
    input_file = models.FileField('Input File', upload_to = 'files/inputs')
    output_file = models.FileField('Output File', upload_to = 'files/outputs')
    def __unicode__(self):
        return self.problem.title + ': Input/Output'

#The submissions from a user are defined here
class Submission(models.Model):
    LANGUAGES = (
        ('c', 'C'),
        ('java', 'Java'),
    )
#    user = models.ForeignKey(User)     
    language = models.CharField('Language', max_length = 10, choices=LANGUAGES)
    program = models.FileField('Program', upload_to = 'files/programs')
    problem = models.ForeignKey(Problem)
    time = models.DateTimeField('Time', auto_now_add=True)
    celery_task = PickledObjectField()  #This saves the result of the celery_task, It gives the key to access the celery task database.
    def get_absolute_url(self):
        return '/submission/%d/' %(self.id)
    def __unicode__(self):
        return 'Submission: ' + self.problem.title# + 'by ' + self.user

#Form for a submission to be made by the user
class SubmissionForm(ModelForm):
    class Meta:
        model = Submission
        exclude = ('celery_task',)
