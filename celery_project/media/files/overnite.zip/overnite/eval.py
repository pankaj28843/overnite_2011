import os




result=dict()       #stores the result


def checkOutput(givenpath,samplepath):

  #opening a given file and a sample file
  givenfile=open(givenpath,'r')
  samplefile=open(samplepath,'r') 

  #reading firstline
  s1=samplefile.readline()
  s2=givenfile.readline()

  while((s1!='')and(s2!='')):        #condition for end of file

    #splitting to omit white space
    x1=s1.split()                   
    x2=s2.split()

    #skipping blank lines 
    while((len(x1)<1)and(s1!='')):
       s1=samplefile.readline()
       x1=s1.split()
    while((len(x2)<1)and(s2!='')):
       s2=samplefile.readline()
       x2=s1.split()
    
    #break in case of mismatch
    if(x1!=x2):
       break

    #break if any file reaches the end
    elif((s1=='')or(s2=='')):
       break

    #read next line
    else:
       s1=samplefile.readline()
       s2=givenfile.readline()


  #if both files a read successfully
  if((s1=='')or(s2=='')):
       result['status']='correct'
  
  #if both files are not read successfully
  else:
       result['status']='incorrect'


def evaluateC(sourcepath,inputpath,outputpath):

  runcmd='cc '+sourcepath
  clean='rm *.out'
  createoutput='./a.out < '+inputpath+' > output.out'

  os.system(clean)     # removing previous .out files

  os.system(runcmd)    # compiling the C code

  #creating output file and comparing with the sample if a.out is generated
  if(os.path.exists('./a.out')):
     os.system(createoutput)
     checkOutput('./output.out',outputpath)

  #status=error is a.out is not generated
  else:
     result['status']='errors'
    



def evaluate(language,sourcepath,inputpath,outputpath):
  if(language=='C'):
    evaluateC(sourcepath,inputpath,outputpath)


if __name__=='__main__':
  evaluate('C','ccodes/sort.c','input/sort.in','output/sort.out')
  print result['status']


